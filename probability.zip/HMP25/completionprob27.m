function[prob,maxerr0,maxerr1,maxerrl]=completionprob27(m,coeff,k,tau,delta,delta2,delta3,delta4)
% Runs m times completionq for the rectangular quadratic matrix polynomial
% of Example 27
% and provides the empirical probability of getting the right
% number of true evals
% It also provides the maximum error for the true finite e-vals, which are 
% 0 (maxerr0), -1 (maxerr1), and 10^4 (maxerrl)
% a is the number of true finite evals
% b is the number of true infinite evals

rng(0);
number=0;
for i=1:m
    [E,evals,inf]=completionq(coeff,k,tau,delta,delta2,delta3,delta4);
    t1=length(evals);
    t2=length(inf);
    if t1==10 && t2==1
        number=number+1;
    end
    error0(i)=min(abs(E));
    error1(i)=min(abs(E+1));
    E1=sort(abs(E-10^4));
    errorl(i)=max(E1(1:5));
end
maxerr0=max(error0);
maxerr1=max(error1);
maxerrl=max(errorl);
prob=number/m;