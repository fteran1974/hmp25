function[prob,maxerr0,maxerr1]=completionprobrect(m,coeff,k,tau,delta,delta2,delta3,delta4)
% Runs m times completionq for the rectangular quadratic matrix polynomial
% of Example 25
% and provides the empirical probability of getting the right
% number of true evals
% It also provides the maximum error for the true finite e-vals, which are 
% 0 (maxerr0) and 1 (maxerr1)
% a is the number of true finite evals
% b is the number of true infinite evals

rng(0);
number=0;
for i=1:m
    [E,evals,inf]=completionq(coeff,k,tau,delta,delta2,delta3,delta4);
    t1=length(evals);
    t2=length(inf);
    if t1==3 && t2==2
        number=number+1;
    end
    E=sort(E);
    [err1,ind]=min(abs(E));
    ind=setdiff(1:8,ind);
    err2=min(abs(E(ind)));
    error0(i)=max([err1,err2]);
    error1(i)=min(abs([E-1]));
end
maxerr0=max(error0);
maxerr1=max(error1);
prob=number/m;