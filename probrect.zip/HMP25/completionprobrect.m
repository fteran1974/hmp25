function[prob,maxerr]=completionprobrect(m,coeff,k,tau,delta,delta2,delta3,delta4)
% Runs m times completionq for a singular quadratic matrix polynomial
% and provides the empirical probability of getting the right
% number of true evals
% a is the number of true finite evals
% b is the number of true infinite evals

rng(0);
number=0;
for i=1:m
    [E,evals,inf]=completionq(coeff,k,tau,delta,delta2,delta3,delta4);
    t1=length(evals);
    t2=length(inf);
    if t1==3 && t2==2
        number=number+1;
    end
E=sort(E);
    [err1,ind]=min(abs(E));
    ind=setdiff(1:8,ind);
    err2=min(abs(E(ind)));
    err3=min(abs([E-1]));
    error(i)=max([err1,err2,err3]);
end
maxerr=max(error);
prob=number/m;